import nltk
import re
import streamlit as st
import pickle

nltk.download('punk')
nltk.download('stopwords')

#loading models
knn = pickle.load(open('knn.pkl', 'rb'))
tfidf = pickle.load(open('tfidf.pkl', 'rb'))

def clean_resume(resume_text):
    clean_text = re.sub('http\S+\s', ' ', resume_text)
    clean_text = re.sub('@\S+', ' ', clean_text)
    clean_text = re.sub('#\S+', ' ', clean_text)
    clean_text = re.sub('RT|CC', ' ', clean_text)
    clean_text = re.sub('\s+', ' ', clean_text)
    clean_text = re.sub(r'[^\x00-\x7f]', ' ', clean_text)
    clean_text = re.sub('[%s]' % re.escape("""!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~"""), ' ', clean_text)

    return clean_text
#website
def main():
    st.title("Resume Detector and Analyser")
    upload_file = st.file_uploader("Upload the Resume", type=['pdf','txt'])

    if upload_file is not None:
        try:
            resume_bytes = upload_file.read()
            resume_bytes = resume_bytes.decode('utf-8')
        except UnicodeDecodeError:
            resume_text = resume_bytes.decode('latin-1')

        cleaned_resume = clean_resume([resume_text])
        input_features = tfidf.transform(cleaned_resume)
        prediction_id = knn.predict(input_features)[0]
        st.write(prediction_id)

        category_mapping = {
            15: "Java Developer",
            23: "Testing",
            8: "DevOps Engineer",
            20: "Python Developer",
            24: "Web Desigener",
            12: "HR",
            13: "Hadoop Developer",
            3: "Blockchain Developer",
            10: "ETL Developer",
            18: "Operations Manager",
            6: "Data Science",
            22: "Sales",
            16: "Mechanical Engineer",
            1: "Arts",
            7: "Database Administrator",
            11: "Electrical Engineer",
            14: "Health and Fitness Expert",
            19: "PMO",
            4: "Business Analyst",
            9: "Dont Net Developer",
            2: "Automation Testing",
            17: "Network Security Engineer",
            21: "SAP Developer",
            5: "Civil Engineer",
            0: "Advocate",
        }

        category_name = category_mapping.get(prediction_id, "Unknown")
        st.write("Professional Background: ", category_name)

#python main
if __name__ == "__main__":
    main()
